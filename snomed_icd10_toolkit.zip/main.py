
import streamlit as st
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import pandas as pd
from difflib import get_close_matches

# Load BioBERT model
@st.cache_resource
def load_model():
    tokenizer = AutoTokenizer.from_pretrained("d4data/biobert-base-cased-ner")
    model = AutoModelForTokenClassification.from_pretrained("d4data/biobert-base-cased-ner")
    return pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")

nlp = load_model()

# Load ICD-10 dataset
@st.cache_data
def load_icd10():
    return pd.read_csv("data/icd10_sample.csv")

icd_df = load_icd10()

def map_to_icd10(term, icd_df):
    matches = get_close_matches(term.lower(), icd_df['Description'].str.lower(), n=1, cutoff=0.6)
    if matches:
        matched_row = icd_df[icd_df['Description'].str.lower() == matches[0]]
        if not matched_row.empty:
            return matched_row.iloc[0].to_dict()
    return {"Code": "N/A", "Description": "No match found"}

# Streamlit UI
st.title("Medical Term Identifier & ICD-10 Mapper")
text_input = st.text_area("Enter medical text:", height=200)

if st.button("Analyze"):
    if text_input:
        st.write("### Identified Medical Terms:")
        terms = nlp(text_input)
        results = []
        for t in terms:
            term_text = t['word']
            mapped = map_to_icd10(term_text, icd_df)
            results.append({
                "Term": term_text,
                "ICD-10 Code": mapped["Code"],
                "ICD-10 Description": mapped["Description"]
            })
        st.dataframe(results)
    else:
        st.warning("Please enter some medical text.")
