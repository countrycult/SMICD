
# SNOMED CT + ICD-10 Medical Term Identifier Toolkit (Streamlit)

## Features
- Input medical text
- Identify medical terms using BioBERT
- Map terms to closest ICD-10 codes

## Instructions

1. Install dependencies:
    pip install streamlit transformers torch pandas scikit-learn

2. Run the app:
    streamlit run main.py

3. Upload full ICD-10 or SNOMED CT datasets to the `data/` directory to scale up.

## Notes
- Uses fuzzy matching for ICD-10 mapping
- Only a sample ICD-10 CSV is included
